# Topic Modeling

The project contains implementations of topic models I have used during my thesis. 
Those implementations have been used for different papers. 

LDA
====

common LDA

SentenceLDA
====

In particular, we have proposed the sentenceLDA in the SIGIR 2016 paper :
 [On a topic model for sentences](https://arxiv.org/pdf/1606.00253v1.pdf).
 

