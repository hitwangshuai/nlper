# coding=utf-8

import nltk
import numpy as np, codecs, json, vocabulary, cPickle as pickle, sys
from datetime import datetime
from nltk.stem import WordNetLemmatizer

class lda_gibbs_sampling:
    def __init__(self, K=25, alpha=0.5, beta=0.5, docs= None, V= None):
        self.K = K
        self.alpha = alpha # parameter of topics prior
        self.beta = beta   # parameter of words prior
        self.docs = docs # a list of lists, each inner list contains the indexes of the words in a doc, e.g.: [[1,2,3],[2,3,5,8,7],[1, 5, 9, 10 ,2, 5]]
        self.V = V # how many different words in the vocabulary i.e., the number of the features of the corpus
        # Definition of the counters 
        self.z_m_n = [] # topic assignements for each of the N words in the corpus. N: total number od words in the corpus (not the vocabulary size).
        self.n_m_z = np.zeros((len(self.docs), K)) + alpha     # |docs|xK topics: number of words assigned to topic z in document m  
        self.n_z_t = np.zeros((K, V)) + beta # (K topics) x |V| : number of times a word v is assigned to a topic z 
        self.n_z = np.zeros(K) + V * beta    # (K,) : overal number of words assigned to a topic z

        self.N = 0
        for m, doc in enumerate(docs):         # Initialization of the data structures I need.
            self.N += len(doc)                 # to find the size of the corpus 
            z_n = []
            for t in doc: 
                z = np.random.randint(0, K) # Randomly assign a topic to a word. Recall, topics have ids 0 ... K-1. randint: returns integers to [0,K[
                z_n.append(z)                  # Keep track of the topic assigned 
                self.n_m_z[m, z] += 1          # increase the number of words assigned to topic z in the m doc.
                self.n_z_t[z, t] += 1          #  .... number of times a word is assigned to this particular topic
                self.n_z[z] += 1               # increase the counter of words assigned to z topic
            self.z_m_n.append(np.array(z_n))# update the array that keeps track of the topic assignements in the words of the corpus.

    def inference(self):
        """    The learning process. Here only one iteration over the data. 
               A loop will be calling this function for as many iterations as needed.     """
        for m, doc in enumerate(self.docs):
            z_n, n_m_z = self.z_m_n[m], self.n_m_z[m]
            for n, t in enumerate(doc):
                z = z_n[n]
                n_m_z[z] -= 1
                self.n_z_t[z, t] -= 1
                self.n_z[z] -= 1
                # sampling topic new_z for t
                p_z = (self.n_z_t[:, t]+self.beta) * (n_m_z+self.alpha) / (self.n_z + self.V*self.beta)                      # A list of len() = # of topic
                new_z = np.random.multinomial(1, p_z / p_z.sum()).argmax()   # One multinomial draw, for a distribution over topics, with probabilities summing to 1, return the index of the topic selected.
                # set z the new topic and increment counters
                z_n[n] = new_z
                n_m_z[new_z] += 1
                self.n_z_t[new_z, t] += 1
                self.n_z[new_z] += 1
    def topicdist(self):
        return self.n_m_z / self.n_m_z.sum(axis=1)[:, np.newaxis]
    
    def worddist(self):
        """get topic-word distribution, \phi in Blei's paper. Returns the distribution of topics and words. (Z topics) x (V words)  """
        return self.n_z_t / self.n_z[:, np.newaxis]  #Normalize each line (lines are topics), with the number of words assigned to this topics to obtain probs.  *neaxis: Create an array of len = 1
    
	def perplexity(self):
		docs = self.docs
        phi = self.worddist()
        log_per, N = 0, 0
        Kalpha = self.K * self.alpha
        for m, doc in enumerate(docs):
            theta = self.n_m_z[m] / (len(docs[m]) + Kalpha)
            for w in doc:
                log_per -= np.log(np.inner(phi[:,w], theta))
            N += len(doc)
        return np.exp(log_per / N)

if __name__ == "__main__":
    st, corpus = datetime.now(), []
    corpus = codecs.open(sys.argv[1], 'r', 'utf-8').read().split('\n')
    for key, val in enumerate(corpus):
        if val == '':
			del(corpus[key])
	
	voca = vocabulary.Vocabulary(set(nltk.corpus.stopwords.words('english')), WordNetLemmatizer(), excluds_stopwords=True)
    docs = [voca.doc_to_ids(doc) for doc in corpus]
    docs = voca.cut_low_freq(docs, 1)

    iterations = 200
    topics = sys.argv[2]
    alpha, beta = 0.5/float(topics), 0.5/float(topics)

    lda = lda_gibbs_sampling(K=int(topics), alpha=alpha, beta=beta, docs=docs, V=voca.size())
    for i in range(iterations):
        print "iteration:", i, 
        starting = datetime.now()
        lda.inference()
        print "Time used: ", datetime.now() - starting
    
	topk = 15 
	_topk =  -1 * topk
    wd = lda.worddist()
    for i in range(int(topics)):
        ind = np.argpartition(wd[i], _topk)[_topk:]
        for j in ind:
            print voca[j],
        print
    print "It finished. Total time:", datetime.now()-st

