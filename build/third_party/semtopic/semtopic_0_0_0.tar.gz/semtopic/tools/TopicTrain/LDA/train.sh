
python lda.py ../data/train.txt 10

