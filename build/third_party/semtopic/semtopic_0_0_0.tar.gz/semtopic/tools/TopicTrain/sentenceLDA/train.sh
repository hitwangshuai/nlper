
python sentenceLda.py ../data/train.txt 10

