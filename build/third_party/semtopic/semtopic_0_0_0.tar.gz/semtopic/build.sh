#!/bin/bash

rootdir=`pwd`
installdir=$rootdir/third_party

cd $installdir

tar -zxf protobuf_3_1_0.tar.gz
cd protobuf && export CFLAGS=-fPIC && export CXXFLAGS=-fPIC
./configure --disable-shared --prefix=$installdir
make -j8 && make install
cd ..
rm -rf protobuf

tar -zxf gflags_2_2_1.tar.gz
cd gflags && export CFLAGS=-fPIC && export CXXFLAGS=-fPIC
cmake -DCMAKE_POSITION_INDEPENDENT_CODE=ON -DBUILD_SHARED_LIBS=ON -DBUILD_STATIC_LIBS=ON -DBUILD_TESTING=OFF -DCMAKE_INSTALL_PREFIX=$installdir ./
make && make install
cd ..
rm -rf gflags

tar -zxf glog_0_3_5.tar.gz
cd glog && export CFLAGS=-fPIC && export CXXFLAGS=-fPIC
./configure --prefix=$installdir --with-gflags=$installdir
make && make install
cd ..
rm -rf glog

cd $rootdir
make clean && make -j20;


