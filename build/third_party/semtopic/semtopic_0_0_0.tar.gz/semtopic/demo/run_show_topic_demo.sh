#!/bin/bash
export LD_LIBRARY_PATH=../third_party/lib:$LD_LIBRARY_PATH

./show_topic_demo --model_dir="../model/news/" --conf_file="lda.conf" --top_k=10

