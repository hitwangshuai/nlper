#!/bin/bash
# 拉取主题模型文件

if [ ! -d news ]; then
    wget ftp://10.11.11.43:/home/wangshuai/repos/datas/topic_model/news.tar.gz
    tar -xzf news.v1.tar.gz
fi

if [ ! -d webpage ]; then
    wget ftp://10.11.11.43:/home/wangshuai/repos/datas/topic_model/webpage.tar.gz
    tar -xzf webpage.tar.gz
fi

if [ ! -d novel ]; then
    wget ftp://10.11.11.43:/home/wangshuai/repos/datas/topic_model/novel.tar.gz
    tar -xzf novel.tar.gz
fi

if [ ! -d weibo ]; then
    wget ftp://10.11.11.43:/home/wangshuai/repos/datas/topic_model/weibo.tar.gz
    tar -xzf weibo.tar.gz
fi

