#!/bin/bash
export LD_LIBRARY_PATH=../third_party/lib:$LD_LIBRARY_PATH

python ./demo/lda_infer_demo.py ../model/news lda.conf
