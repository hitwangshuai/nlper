#!/bin/bash
export LD_LIBRARY_PATH=../third_party/lib:$LD_LIBRARY_PATH

python demo/topic_word_demo.py ../model/news news_twe_lda.model
